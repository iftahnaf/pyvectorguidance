# General Info
Vector Guidance method implemented in Python.
